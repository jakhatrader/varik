// patch-neon.js — cyberpunk skin + card rework for public/index.html:
//   1. loads neon.css,
//   2. drops the duplicate download button and the stray project link from the
//      action rows (they were four buttons doing three things),
//   3. stops the saved PNG from printing the domain twice,
//   4. puts rank art behind the card, chosen by the best of the three ranks.
// Usage: node patch-neon.js public/index.html
// Idempotent: re-running reports SKIP.

const fs = require('fs');
const file = process.argv[2] || 'public/index.html';
let s = fs.readFileSync(file, 'utf8');

if (s.indexOf('neon.css') !== -1) { console.log('SKIP: neon skin already applied to ' + file); process.exit(0); }

let ok = 0, miss = 0;
function rep(name, find, replace) {
	if (s.indexOf(find) === -1) { console.log('MISS: ' + name); miss++; return; }
	s = s.split(find).join(replace);
	console.log('ok:   ' + name);
	ok++;
}

/* ---------- 1. stylesheet ---------- */

rep('link: neon.css', '<script src="i18n.js"></script>', '<link rel="stylesheet" href="neon.css">\n<script src="i18n.js"></script>');

/* ---------- 2. action rows ---------- */

// The scan card had both "Save image" and "Download PNG" — same output, two buttons.
rep('card: drop duplicate download button',
	'\t\t\t\t<button class="pov-btn pov-btn-ghost" id="downloadCardBtn" type="button">⬇ <span data-i18n="btn.downloadPng">Download PNG</span></button>\n',
	'');
rep('card: relabel capture button',
	'<button class="pov-btn pov-btn-ghost pov-shotbtn" id="cSaveImg" type="button">📷 <span data-i18n="btn.saveImage">Save image</span></button>',
	'<button class="pov-btn pov-btn-ghost pov-shotbtn" id="cSaveImg" type="button">⬇ <span data-i18n="btn.downloadPng">Download PNG</span></button>');

rep('profile: drop duplicate download button',
	'\t\t\t\t<button class="pov-btn pov-btn-ghost" id="downloadProfileBtn" type="button">⬇ <span data-i18n="btn.downloadPng">Download PNG</span></button>\n',
	'');
// The project link belongs in the header, not in the row of actions for this profile.
rep('profile: drop stray project link',
	'\t\t\t\t<a class="pov-btn pov-btn-ghost" href="https://x.com/variational_io" target="_blank" rel="noopener">@variational_io</a>\n',
	'');
rep('profile: relabel capture button',
	'<button class="pov-btn pov-btn-ghost pov-shotbtn" id="pSaveImg" type="button">📷 <span data-i18n="btn.saveImage">Save image</span></button>',
	'<button class="pov-btn pov-btn-ghost pov-shotbtn" id="pSaveImg" type="button">⬇ <span data-i18n="btn.downloadPng">Download PNG</span></button>');

/* ---------- 3. one domain per saved image ---------- */

// The capture bar used to print the domain, and the card already carries it in its
// corner — so the PNG showed ogvar.xyz twice. The bar keeps the brand line only.
rep('capture bar: no second domain',
	"function makeBar(){var bar=document.createElement('div');bar.className='pov-shot-bar';var b=document.createElement('span');b.className='b';b.textContent=brandText();var d=document.createElement('span');d.className='d';d.textContent=DOMAIN;bar.appendChild(b);bar.appendChild(d);return bar;}",
	"function makeBar(){var bar=document.createElement('div');bar.className='pov-shot-bar';var b=document.createElement('span');b.className='b';b.textContent=brandText();bar.appendChild(b);return bar;}");

/* ---------- 4. rank art ---------- */

rep('js: rank art helper',
	'\t/* ---------- scan card (hero) ---------- */',
	'\t/* ---------- rank art ---------- */\n' +
	'\t// The best of the three ranks decides the character behind the card, so a\n' +
	'\t// top-20 poster keeps their art even if their view rank is mid-table.\n' +
	"\tvar RANK_ART=[[20,'gigachad'],[50,'sigma'],[100,'headphones'],[200,'gatsby'],[300,'cap'],[500,'beanie']];\n" +
	'\tfunction rankTier(ranks){\n' +
	'\t\tif(!ranks)return null;\n' +
	'\t\tvar best=Math.min(ranks.v||1e9,ranks.l||1e9,ranks.p||1e9);\n' +
	'\t\tfor(var i=0;i<RANK_ART.length;i++){if(best<=RANK_ART[i][0])return RANK_ART[i][1];}\n' +
	'\t\treturn null; // 501 and below: plain card\n' +
	'\t}\n' +
	'\tfunction setRankArt(node,ranks){\n' +
	'\t\tif(!node)return;\n' +
	"\t\tvar art=node.querySelector('.pov-rank-art');\n" +
	'\t\tvar tier=rankTier(ranks);\n' +
	'\t\tif(!tier){if(art&&art.parentNode)art.parentNode.removeChild(art);return;}\n' +
	"\t\tvar src='ranks/'+tier+'.webp';\n" +
	"\t\tif(!art){art=document.createElement('img');art.className='pov-rank-art';art.setAttribute('alt','');art.setAttribute('aria-hidden','true');node.insertBefore(art,node.firstChild);}\n" +
	"\t\tif(art.getAttribute('src')!==src)art.setAttribute('src',src);\n" +
	'\t}\n\n' +
	'\t/* ---------- scan card (hero) ---------- */');

rep('js: rank art on scan card',
	"_csr('cRankV','👁',T('card.views'),_crk.v);_csr('cRankL','❤',T('card.likes'),_crk.l);_csr('cRankP','📝',T('card.posts'),_crk.p);",
	"_csr('cRankV','👁',T('card.views'),_crk.v);_csr('cRankL','❤',T('card.likes'),_crk.l);_csr('cRankP','📝',T('card.posts'),_crk.p);setRankArt(document.getElementById('card'),_crk);");

rep('js: rank art on profile',
	"_sr('pRankV','👁',T('card.views'),_rk.v);_sr('pRankL','❤',T('card.likes'),_rk.l);_sr('pRankP','📝',T('card.posts'),_rk.p);",
	"_sr('pRankV','👁',T('card.views'),_rk.v);_sr('pRankL','❤',T('card.likes'),_rk.l);_sr('pRankP','📝',T('card.posts'),_rk.p);setRankArt(document.getElementById('profileSnap'),_rk);");

if (miss) { console.log('\nABORTED: ' + miss + ' target(s) not found — nothing written.'); process.exit(1); }
fs.writeFileSync(file, s);
console.log('\nDONE: ' + ok + ' edit(s) written to ' + file);
