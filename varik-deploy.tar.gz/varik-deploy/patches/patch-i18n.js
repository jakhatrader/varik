// patch-i18n.js — wires public/i18n.js into public/index.html:
//   1. loads the dictionary before the app script,
//   2. tags every static string with data-i18n / data-i18n-ph / data-i18n-html,
//   3. rewrites every string the app builds at runtime to go through I18N.t(),
//   4. re-renders the whole page when the language changes.
// Usage: node patch-i18n.js public/index.html
// Idempotent: re-running reports SKIP.

const fs = require('fs');
const file = process.argv[2] || 'public/index.html';
let s = fs.readFileSync(file, 'utf8');

if (s.indexOf('i18n.js') !== -1) { console.log('SKIP: i18n already wired into ' + file); process.exit(0); }

let ok = 0, miss = 0;
function rep(name, find, replace) {
	if (s.indexOf(find) === -1) { console.log('MISS: ' + name); miss++; return; }
	s = s.split(find).join(replace);
	console.log('ok:   ' + name);
	ok++;
}

/* ---------- 1. load the dictionary + selector styling ---------- */

rep('style: language selector',
	'</style>',
	'.pov-lang{background:rgba(120,160,255,0.08);color:var(--text);border:1px solid var(--border);border-radius:11px;padding:9px 12px;font-weight:700;font-size:14px;font-family:inherit;cursor:pointer;outline:none;}\n' +
	'.pov-lang:hover{background:rgba(120,160,255,0.14);}\n' +
	'.pov-lang option{background:#0f1a36;color:#e8eeff;}\n' +
	'@media(max-width:640px){.pov-lang{padding:8px 10px;font-size:13px;}}\n' +
	'</style>');

rep('script: i18n.js before the app',
	'<body>',
	'<script src="i18n.js"></script>\n<body>');

/* ---------- 2. static strings ---------- */

rep('hero: badge', '<span class="notion-eyebrow" id="srcBadge">Loading live data…</span>',
	'<span class="notion-eyebrow" id="srcBadge" data-i18n="badge.loading">Loading live data…</span>');

rep('hero: tagline',
	'<p class="pov-tagline">See how much someone has helped <a href="https://x.com/variational_io" target="_blank" rel="noopener">Variational</a> grow on X / Twitter. Index any account, open its profile, and share the card.</p>',
	'<p class="pov-tagline" data-i18n="hero.tagline">See how much someone has helped Variational grow on X / Twitter. Index any account, open its profile, and share the card.</p>');

rep('hero: scan placeholder', 'placeholder="your_x_handle"', 'placeholder="your_x_handle" data-i18n-ph="hero.placeholder"');
rep('hero: scan button', 'id="scanBtn" type="button">Scan</button>', 'id="scanBtn" type="button" data-i18n="hero.scan">Scan</button>');

rep('hero: hint',
	'<p class="pov-hint">Type any X handle and hit Scan — or click anyone on the leaderboard to open their profile.</p>',
	'<p class="pov-hint" data-i18n="hero.hint">Type any X handle and hit Scan — or click anyone on the leaderboard to open their profile.</p>');

rep('card: stat labels',
	'<div class="pov-card-stat"><div class="k">Views</div><div class="v" id="cViews">0</div></div>\n\t\t\t\t\t<div class="pov-card-stat"><div class="k">Likes</div><div class="v" id="cLikes">0</div></div>\n\t\t\t\t\t<div class="pov-card-stat"><div class="k">Posts</div><div class="v" id="cPosts">0</div></div>',
	'<div class="pov-card-stat"><div class="k" data-i18n="card.views">Views</div><div class="v" id="cViews">0</div></div>\n\t\t\t\t\t<div class="pov-card-stat"><div class="k" data-i18n="card.likes">Likes</div><div class="v" id="cLikes">0</div></div>\n\t\t\t\t\t<div class="pov-card-stat"><div class="k" data-i18n="card.posts">Posts</div><div class="v" id="cPosts">0</div></div>');

rep('card: NOW', '\t\t\t\t\t\tNOW\n', '\t\t\t\t\t\t<span data-i18n="card.now">NOW</span>\n');

rep('card: share button', '>𝕏 Share on X</a>', '>𝕏 <span data-i18n="btn.shareX">Share on X</span></a>');
rep('card: view profile', 'id="openProfileBtn" type="button">View full profile →</button>',
	'id="openProfileBtn" type="button" data-i18n="btn.viewProfile">View full profile →</button>');
rep('card: save image', 'id="cSaveImg" type="button">📷 Save image</button>',
	'id="cSaveImg" type="button">📷 <span data-i18n="btn.saveImage">Save image</span></button>');
rep('card: download png', 'id="downloadCardBtn" type="button">⬇ Download PNG</button>',
	'id="downloadCardBtn" type="button">⬇ <span data-i18n="btn.downloadPng">Download PNG</span></button>');

rep('profile: back button', 'id="backBtn" type="button">← Back to leaderboard</button>',
	'id="backBtn" type="button" data-i18n="btn.back">← Back to leaderboard</button>');
rep('profile: share button', '>𝕏 Share this profile</a>', '>𝕏 <span data-i18n="btn.shareProfile">Share this profile</span></a>');
rep('profile: save image', 'id="pSaveImg" type="button">📷 Save image</button>',
	'id="pSaveImg" type="button">📷 <span data-i18n="btn.saveImage">Save image</span></button>');
rep('profile: download png', 'id="downloadProfileBtn" type="button">⬇ Download PNG</button>',
	'id="downloadProfileBtn" type="button">⬇ <span data-i18n="btn.downloadPng">Download PNG</span></button>');

rep('profile: stat labels',
	'<div class="pov-card-stat"><div class="k">Total views</div><div class="v" id="pViews">0</div></div>\n\t\t\t\t\t<div class="pov-card-stat"><div class="k">Total likes</div><div class="v" id="pLikes">0</div></div>\n\t\t\t\t\t<div class="pov-card-stat"><div class="k">Total posts</div><div class="v" id="pPosts">0</div></div>',
	'<div class="pov-card-stat"><div class="k" data-i18n="prof.totalViews">Total views</div><div class="v" id="pViews">0</div></div>\n\t\t\t\t\t<div class="pov-card-stat"><div class="k" data-i18n="prof.totalLikes">Total likes</div><div class="v" id="pLikes">0</div></div>\n\t\t\t\t\t<div class="pov-card-stat"><div class="k" data-i18n="prof.totalPosts">Total posts</div><div class="v" id="pPosts">0</div></div>');

rep('profile: breakdown heading', '<h3 class="pov-prof-h3">Mention breakdown</h3>',
	'<h3 class="pov-prof-h3" data-i18n="prof.breakdown">Mention breakdown</h3>');

rep('profile: breakdown cards',
	'<div class="pov-bd"><div class="pov-bd-k">🔗 <span class="pov-tag">@variational_io</span></div><div class="pov-bd-v" id="pAt">0</div><div class="pov-bd-c">posts mentioning the account</div></div>\n\t\t\t\t<div class="pov-bd"><div class="pov-bd-k">📝 keyword “variational”</div><div class="pov-bd-v" id="pKw">0</div><div class="pov-bd-c">posts using the keyword</div></div>\n\t\t\t\t<div class="pov-bd"><div class="pov-bd-k">💵 <span class="pov-tag">$VAR</span> tag</div><div class="pov-bd-v" id="pVar">0</div><div class="pov-bd-c">posts with the $VAR tag</div></div>\n\t\t\t\t<div class="pov-bd"><div class="pov-bd-k">💬 replies w/ commentary</div><div class="pov-bd-v" id="pReply">0</div><div class="pov-bd-c">substantive replies to @variational_io</div></div>',
	'<div class="pov-bd"><div class="pov-bd-k">🔗 <span class="pov-tag">@variational_io</span></div><div class="pov-bd-v" id="pAt">0</div><div class="pov-bd-c" data-i18n="prof.bdAtCap">posts mentioning the account</div></div>\n\t\t\t\t<div class="pov-bd"><div class="pov-bd-k">📝 <span data-i18n="prof.bdKwTitle">keyword “variational”</span></div><div class="pov-bd-v" id="pKw">0</div><div class="pov-bd-c" data-i18n="prof.bdKwCap">posts using the keyword</div></div>\n\t\t\t\t<div class="pov-bd"><div class="pov-bd-k">💵 <span class="pov-tag">$VAR</span> <span data-i18n="prof.bdVarTitle">tag</span></div><div class="pov-bd-v" id="pVar">0</div><div class="pov-bd-c" data-i18n="prof.bdVarCap">posts with the $VAR tag</div></div>\n\t\t\t\t<div class="pov-bd"><div class="pov-bd-k">💬 <span data-i18n="prof.bdReplyTitle">replies w/ commentary</span></div><div class="pov-bd-v" id="pReply">0</div><div class="pov-bd-c" data-i18n="prof.bdReplyCap">substantive replies to @variational_io</div></div>');

rep('profile: top posts heading', '<h3 class="pov-prof-h3">Top posts</h3>',
	'<h3 class="pov-prof-h3" data-i18n="prof.topPosts">Top posts</h3>');

rep('stats: cards',
	'<div class="pov-stat"><p class="pov-stat-label">Total views</p><p class="pov-stat-value" id="totalViews">0</p><p class="pov-stat-cap">All Variational-related views, summed across every indexed account.</p></div>\n\t\t\t<div class="pov-stat"><p class="pov-stat-label">Total likes</p><p class="pov-stat-value" id="totalLikes">0</p><p class="pov-stat-cap">All likes on Variational-related posts, summed across accounts.</p></div>\n\t\t\t<div class="pov-stat"><p class="pov-stat-label">Total posts</p><p class="pov-stat-value" id="totalPosts">0</p><p class="pov-stat-cap">Total Variational-related posts across all indexed accounts.</p></div>',
	'<div class="pov-stat"><p class="pov-stat-label" data-i18n="stats.totalViews">Total views</p><p class="pov-stat-value" id="totalViews">0</p><p class="pov-stat-cap" data-i18n="stats.totalViewsCap">All Variational-related views, summed across every indexed account.</p></div>\n\t\t\t<div class="pov-stat"><p class="pov-stat-label" data-i18n="stats.totalLikes">Total likes</p><p class="pov-stat-value" id="totalLikes">0</p><p class="pov-stat-cap" data-i18n="stats.totalLikesCap">All likes on Variational-related posts, summed across accounts.</p></div>\n\t\t\t<div class="pov-stat"><p class="pov-stat-label" data-i18n="stats.totalPosts">Total posts</p><p class="pov-stat-value" id="totalPosts">0</p><p class="pov-stat-cap" data-i18n="stats.totalPostsCap">Total Variational-related posts across all indexed accounts.</p></div>');

rep('stats: indexed users',
	'<div class="pov-stat"><p class="pov-stat-label">Indexed users</p><p class="pov-stat-value" id="totalUsers">0</p><p class="pov-stat-cap">How many accounts appear in the indexed sample.</p></div>',
	'<div class="pov-stat"><p class="pov-stat-label" data-i18n="stats.users">Indexed users</p><p class="pov-stat-value" id="totalUsers">0</p><p class="pov-stat-cap" data-i18n="stats.usersCap">How many accounts appear in the indexed sample.</p></div>');

rep('callout',
	'<strong>What gets counted</strong>\n\t\t\t\t<p>Original posts, quote tweets, <em>and replies with commentary</em> that contain a mention of <span class="pov-tag">@variational_io</span>, the keyword <strong>“variational”</strong>, or the <span class="pov-tag">$VAR</span> tag. Plain retweets and empty replies are excluded.</p>',
	'<strong data-i18n="callout.title">What gets counted</strong>\n\t\t\t\t<p data-i18n-html="callout.body">Original posts, quote tweets, <em>and replies with commentary</em> that contain a mention of <span class="pov-tag">@variational_io</span> or the keyword <strong>“variational”</strong>. Plain retweets and empty replies are excluded.</p>');

rep('leaderboard: heading', '<h2 class="pov-h2">Leaderboard</h2>', '<h2 class="pov-h2" data-i18n="lb.title">Leaderboard</h2>');
rep('leaderboard: search placeholder', 'placeholder="Search a handle…"', 'placeholder="Search a handle…" data-i18n-ph="lb.search"');
rep('leaderboard: rank by', '<span class="pov-sort-lbl">Rank by</span>', '<span class="pov-sort-lbl" data-i18n="lb.rankBy">Rank by</span>');

rep('leaderboard: sort buttons',
	'<button type="button" class="pov-sort-btn active" data-k="v">👁 Views</button>\n\t\t\t<button type="button" class="pov-sort-btn" data-k="l">❤ Likes</button>\n\t\t\t<button type="button" class="pov-sort-btn" data-k="p">📝 Posts</button>',
	'<button type="button" class="pov-sort-btn active" data-k="v">👁 <span data-i18n="card.views">Views</span></button>\n\t\t\t<button type="button" class="pov-sort-btn" data-k="l">❤ <span data-i18n="card.likes">Likes</span></button>\n\t\t\t<button type="button" class="pov-sort-btn" data-k="p">📝 <span data-i18n="card.posts">Posts</span></button>');

rep('leaderboard: table head',
	'<thead><tr><th class="pov-rk">#</th><th>User</th><th class="num" data-col="v">Views</th><th class="num" data-col="l">Likes</th><th class="num" data-col="p">Posts</th></tr></thead>',
	'<thead><tr><th class="pov-rk">#</th><th data-i18n="lb.thUser">User</th><th class="num" data-col="v" data-i18n="card.views">Views</th><th class="num" data-col="l" data-i18n="card.likes">Likes</th><th class="num" data-col="p" data-i18n="card.posts">Posts</th></tr></thead>');

rep('leaderboard: foot', '<div class="pov-lb-foot" id="lbFoot">Loading…</div>',
	'<div class="pov-lb-foot" id="lbFoot" data-i18n="lb.loading">Loading…</div>');

rep('cta: heading', '<h2>About the Variational referral</h2>', '<h2 data-i18n="cta.title">About the Variational referral</h2>');
rep('cta: body',
	'<p>Proof of VARIATIONAL is an unofficial community tracker and is not affiliated with Variational. If you choose to trade on Variational, the optional referral code below applies a +15% points boost.</p>',
	'<p data-i18n="cta.body">Proof of VARIATIONAL is an unofficial community tracker and is not affiliated with Variational. If you choose to trade on Variational, the optional referral code below applies a +15% points boost.</p>');
rep('cta: code', '>Optional code: OMNIMUAR</a>', ' data-i18n="cta.code">Optional code: OMNIMUAR</a>');
rep('cta: boost pill', '<span class="pov-boost-pill">+15% POINTS BOOST</span>',
	'<span class="pov-boost-pill" data-i18n="cta.boost">+15% POINTS BOOST</span>');

rep('about: heading', '<h2 class="pov-h2">About Variational</h2>', '<h2 class="pov-h2" data-i18n="about.title">About Variational</h2>');
rep('about: feature cards',
	'<div class="pov-fcard"><div class="pov-fic">⚡</div><h3>Zero-fee perps</h3><p>Var offers up to 50x leverage with zero trading fees, loss refunds, and rewards that flow back to traders.</p></div>\n\t\t\t<div class="pov-fcard"><div class="pov-fic">🔗</div><h3>RFQ, not order books</h3><p>A peer-to-peer Request-for-Quote model aggregates the deepest liquidity from CEXs, DEXs and OTC.</p></div>\n\t\t\t<div class="pov-fcard"><div class="pov-fic">🔒</div><h3>Settled on-chain</h3><p>Trades clear and settle on Arbitrum in isolated escrow smart contracts. $200B+ volume processed.</p></div>',
	'<div class="pov-fcard"><div class="pov-fic">⚡</div><h3 data-i18n="about.f1t">Zero-fee perps</h3><p data-i18n="about.f1b">Var offers up to 50x leverage with zero trading fees, loss refunds, and rewards that flow back to traders.</p></div>\n\t\t\t<div class="pov-fcard"><div class="pov-fic">🔗</div><h3 data-i18n="about.f2t">RFQ, not order books</h3><p data-i18n="about.f2b">A peer-to-peer Request-for-Quote model aggregates the deepest liquidity from CEXs, DEXs and OTC.</p></div>\n\t\t\t<div class="pov-fcard"><div class="pov-fic">🔒</div><h3 data-i18n="about.f3t">Settled on-chain</h3><p data-i18n="about.f3b">Trades clear and settle on Arbitrum in isolated escrow smart contracts. $200B+ volume processed.</p></div>');

/* ---------- 3. runtime strings ---------- */

rep('js: number formatting',
	"\tvar fmt=function(n){return Math.round(n).toLocaleString('en-US');};",
	"\tvar fmt=function(n){return window.I18N?I18N.num(n):Math.round(n).toLocaleString('en-US');};\n\tvar T=function(k,p){return window.I18N?I18N.t(k,p):k;};");

rep('js: compact numbers',
	"\tfunction compact(n){if(n>=1e9)",
	"\tfunction compact(n){if(window.I18N)return I18N.compact(n);if(n>=1e9)");

rep('js: date labels',
	"\tvar MONTHS=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];\n\tfunction dateLabel(ms){if(!ms)return '—';var d=new Date(ms);return MONTHS[d.getMonth()]+' '+d.getDate()+', '+d.getFullYear();}",
	"\tfunction dateLabel(ms){if(!ms)return '—';if(window.I18N)return I18N.dateLabel(ms);return new Date(ms).toDateString();}");

rep('js: update note',
	"\tfunction setUpdNote(real,generatedAt,nextAt){\n\t\tvar el=document.getElementById('updText');if(!el)return;var every=(UPD_HOURS===24?'24 hours':(UPD_HOURS+' hours'));\n\t\tif(real&&generatedAt){var g=new Date(generatedAt);var when=g.toLocaleString('en-US',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});var txt='Data refreshes once every '+every+' · last updated '+when;if(nextAt){var nd=new Date(nextAt);txt+=' · next '+nd.toLocaleString('en-US',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});}el.textContent=txt;}\n\t\telse{el.textContent='Data refreshes once every '+every+' (live once the backend is connected)';}\n\t}",
	"\tvar _updState=null;\n\tfunction setUpdNote(real,generatedAt,nextAt){\n\t\t_updState={real:real,g:generatedAt,n:nextAt};\n\t\tvar el=document.getElementById('updText');if(!el)return;\n\t\tvar every=T('upd.hours',{n:UPD_HOURS});\n\t\tif(real&&generatedAt){\n\t\t\tvar when=window.I18N?I18N.dateTimeLabel(Date.parse(generatedAt)):generatedAt;\n\t\t\tvar txt=T('upd.refresh',{hours:every})+' · '+T('upd.last',{when:when});\n\t\t\tif(nextAt){var nw=window.I18N?I18N.dateTimeLabel(Date.parse(nextAt)):nextAt;txt+=' · '+T('upd.next',{when:nw});}\n\t\t\tel.textContent=txt;\n\t\t}else{el.textContent=T('upd.previewNote',{hours:every});}\n\t}");

rep('js: source badge',
	"\tfunction setBadge(real,info){var b=document.getElementById('srcBadge');if(real){b.innerHTML='\\uD83D\\uDFE2 LIVE data from X · '+(info||'');b.style.color='#4fd2ff';document.getElementById('footNote').insertAdjacentHTML('beforeend',' Live stats are sampled from public X data via twitterapi.io and refreshed once every '+UPD_HOURS+' hours.');}else{b.innerHTML='\\uD83D\\uDFE1 PREVIEW — illustrative data (backend not connected)';document.getElementById('footNote').insertAdjacentHTML('beforeend',' This deployment is showing illustrative preview data because the data backend is not connected.');}}",
	"\tvar _badgeState=null;\n\tfunction setBadge(real,info){\n\t\t_badgeState={real:real,info:info};\n\t\tvar b=document.getElementById('srcBadge');var f=document.getElementById('footNote');\n\t\tif(real){b.innerHTML='\\uD83D\\uDFE2 '+T('badge.live')+' · '+(info||'');b.style.color='#4fd2ff';if(f)f.textContent=T('foot.note')+T('foot.live',{h:UPD_HOURS});}\n\t\telse{b.innerHTML='\\uD83D\\uDFE1 '+T('badge.preview');if(f)f.textContent=T('foot.note')+T('foot.preview');}\n\t}");

rep('js: leaderboard row link',
	"'</span><span class=\"pov-go\">view →</span></div></td>'",
	"'</span><span class=\"pov-go\">'+escHTML(T('lb.view'))+'</span></div></td>'");

rep('js: leaderboard footer',
	"\t\tdocument.getElementById('lbFoot').textContent=filter?('Showing '+shown+' matching account'+(shown===1?'':'s')):('Showing all '+shown+' indexed accounts · scroll for more');",
	"\t\tdocument.getElementById('lbFoot').textContent=filter?(shown===1?T('lb.showingOne'):T('lb.showingN',{n:fmt(shown)})):T('lb.showingAll',{n:fmt(shown)});");

rep('js: scan button state',
	"var btn=document.getElementById('scanBtn');btn.disabled=true;var old=btn.textContent;btn.textContent='Scanning\\u2026';\n\t\tfunction done(){btn.disabled=false;btn.textContent=old;input.value='';}",
	"var btn=document.getElementById('scanBtn');btn.disabled=true;var old=btn.innerHTML;btn.textContent=T('btn.scanning');\n\t\tfunction done(){btn.disabled=false;btn.innerHTML=old;input.value='';}");

rep('js: card followers',
	"document.getElementById('cHandle').textContent='@'+u.h+' · '+compact(u.followers||0)+' followers';",
	"document.getElementById('cHandle').textContent='@'+u.h+' · '+T('card.followers',{n:compact(u.followers||0)});");

rep('js: card rank chips',
	"_csr('cRankV','👁','Views',_crk.v);_csr('cRankL','❤','Likes',_crk.l);_csr('cRankP','📝','Posts',_crk.p);",
	"_csr('cRankV','👁',T('card.views'),_crk.v);_csr('cRankL','❤',T('card.likes'),_crk.l);_csr('cRankP','📝',T('card.posts'),_crk.p);");

rep('js: card first post',
	"document.getElementById('cFirst').textContent='FIRST POST · '+dateLabel(u.first);",
	"document.getElementById('cFirst').textContent=T('card.firstPost')+' · '+dateLabel(u.first);");

rep('js: share text (self)',
	"\t\tvar txt='I\\u2019ve generated '+compact(u.v)+' views helping @variational_io grow on X 📈\\n\\nRank #'+rank+' on Proof of VARIATIONAL. Check yours 👇';",
	"\t\tvar txt=T('share.self',{v:compact(u.v),r:rank});");

rep('js: share text (profile)',
	"\t\tvar txt='@'+u.h+' has generated '+compact(u.v)+' views helping @variational_io grow on X 📈\\n\\nRank #'+rank+' on Proof of VARIATIONAL 👇';",
	"\t\tvar txt=T('share.other',{h:u.h,v:compact(u.v),r:rank});");

rep('js: profile rank chips',
	"_sr('pRankV','👁','Views',_rk.v);_sr('pRankL','❤','Likes',_rk.l);_sr('pRankP','📝','Posts',_rk.p);",
	"_sr('pRankV','👁',T('card.views'),_rk.v);_sr('pRankL','❤',T('card.likes'),_rk.l);_sr('pRankP','📝',T('card.posts'),_rk.p);");

rep('js: profile followers',
	"document.getElementById('pFollowers').textContent=compact(u.followers||0)+' followers';",
	"document.getElementById('pFollowers').textContent=T('card.followers',{n:compact(u.followers||0)});");

rep('js: profile first/last post',
	"\t\tvar fl='';if(u.first)fl='First post: '+dateLabel(u.first);if(u.last)fl+=(fl?'  ·  ':'')+'Last post: '+dateLabel(u.last);",
	"\t\tvar fl='';if(u.first)fl=T('prof.firstPost',{d:dateLabel(u.first)});if(u.last)fl+=(fl?'  ·  ':'')+T('prof.lastPost',{d:dateLabel(u.last)});");

rep('js: empty post list',
	"if(!posts.length){box.innerHTML='<p class=\"notion-muted\">No individual posts found for this account in the current sample. Post-level data appears here once the account is indexed from live X data.</p>';return;}",
	"if(!posts.length){box.innerHTML='<p class=\"notion-muted\">'+escHTML(T('prof.noPosts'))+'</p>';return;}");

rep('js: post meta',
	"escHTML(pp.text||'(no text)')+'</div>'+'<div class=\"pov-post-meta\"><span class=\"vv\">👁 '+compact(pp.v||0)+' views</span>",
	"escHTML(pp.text||T('prof.noText'))+'</div>'+'<div class=\"pov-post-meta\"><span class=\"vv\">👁 '+T('post.views',{n:compact(pp.v||0)})+'</span>");

rep('js: profile loading state',
	"else{document.getElementById('pName').textContent='Loading @'+handle+'\\u2026';document.getElementById('pAvatar').innerHTML=avatarHTML(handle,'');document.getElementById('pPostsList').innerHTML='<p class=\"notion-muted\">Loading posts…</p>';}",
	"else{document.getElementById('pName').textContent=T('prof.loading',{h:handle});document.getElementById('pAvatar').innerHTML=avatarHTML(handle,'');document.getElementById('pPostsList').innerHTML='<p class=\"notion-muted\">'+escHTML(T('prof.loadingPosts'))+'</p>';}");

rep('js: chart tooltip',
	"var tip=dateLabel(p.t)+' · '+compact(p.v)+' views'+(p.text?(' — '+p.text):'');",
	"var tip=dateLabel(p.t)+' · '+T('post.views',{n:compact(p.v)})+(p.text?(' — '+p.text):'');");

rep('js: chart hover tip',
	"tip.innerHTML='<b>'+compact(pt.cv)+' views</b><span>'+dateLabel(pt.t)+'</span>';",
	"tip.innerHTML='<b>'+escHTML(T('post.views',{n:compact(pt.cv)}))+'</b><span>'+dateLabel(pt.t)+'</span>';");

rep('js: png export',
	"if(typeof html2canvas==='undefined'){alert('Image export is still loading — check your connection and try again.');return;}var old=btn?btn.textContent:'';if(btn){btn.disabled=true;btn.textContent='Rendering…';}",
	"if(typeof html2canvas==='undefined'){alert(T('err.exportLoading'));return;}var old=btn?btn.innerHTML:'';if(btn){btn.disabled=true;btn.textContent=T('btn.rendering');}");

rep('js: png export failure',
	".catch(function(){alert('Could not generate the image. Please try again.');}).then(function(){node.style.borderRadius=_br;if(btn){btn.disabled=false;btn.textContent=old;}});",
	".catch(function(){alert(T('err.exportFailed'));}).then(function(){node.style.borderRadius=_br;if(btn){btn.disabled=false;btn.innerHTML=old;}});");

rep('js: live badge info + subtitle',
	"\t\t\tsetBadge(true,'all time · '+idx.toLocaleString('en-US')+' posts indexed'+(progressing?' · still indexing history…':''));\n\t\t\tsetUpdNote(true,d.generatedAt,d.nextUpdateAt);\n\t\t\tdocument.getElementById('lbSub').textContent='Ranked by real Variational-related views on X (all time'+(w.sinceDate?', since '+w.sinceDate:'')+'). '+(progressing?'History is still being indexed — totals will keep growing. ':'')+'Updated once every '+UPD_HOURS+' hours · click anyone to open their profile.';",
	"\t\t\t_liveState={idx:idx,progressing:progressing,since:w.sinceDate||''};\n\t\t\trenderLiveText();\n\t\t\tsetUpdNote(true,d.generatedAt,d.nextUpdateAt);");

rep('js: preview subtitle',
	"}).catch(function(){loadDemo();setUpdNote(false);document.getElementById('lbSub').textContent='Ranked by total Variational-related views on X (all time). Click anyone to open their profile.';renderTotals();renderBoard();route();});",
	"}).catch(function(){loadDemo();setUpdNote(false);_liveState=null;document.getElementById('lbSub').textContent=T('lb.subPreview');renderTotals();renderBoard();route();});");

/* live-text helper + re-render on language change */
rep('js: language change hook',
	"\t/* ---------- init: try live backend, fall back to preview ---------- */",
	"\t/* ---------- language ---------- */\n" +
	"\tvar _liveState=null;\n" +
	"\tfunction renderLiveText(){\n" +
	"\t\tif(!_liveState)return;\n" +
	"\t\tsetBadge(true,T('badge.allTime')+' · '+T('badge.indexed',{n:fmt(_liveState.idx)})+(_liveState.progressing?(' · '+T('badge.indexing')):''));\n" +
	"\t\tvar el=document.getElementById('lbSub');\n" +
	"\t\tif(el)el.textContent=T('lb.subLive',{since:_liveState.since?T('lb.since',{d:_liveState.since}):'',progress:_liveState.progressing?T('lb.progress'):'',hours:T('upd.hours',{n:UPD_HOURS})});\n" +
	"\t}\n" +
	"\t// Everything the app drew itself has to be rebuilt in the new language:\n" +
	"\t// the static markup is handled by I18N.apply(), this covers the rest.\n" +
	"\twindow.addEventListener('i18n:change',function(){\n" +
	"\t\ttry{\n" +
	"\t\t\trenderTotals();renderBoard();\n" +
	"\t\t\tif(_liveState)renderLiveText();else{var sb=document.getElementById('lbSub');if(sb)sb.textContent=T('lb.subPreview');if(_badgeState)setBadge(false);}\n" +
	"\t\t\tif(_updState)setUpdNote(_updState.real,_updState.g,_updState.n);\n" +
	"\t\t\tif(lastShown)showResult(lastShown,mergeRank(lastShown));\n" +
	"\t\t\tvar h=currentHandle();if(h)openProfile(h);\n" +
	"\t\t}catch(e){}\n" +
	"\t});\n\n" +
	"\t/* ---------- init: try live backend, fall back to preview ---------- */");

if (miss) { console.log('\nABORTED: ' + miss + ' target(s) not found — nothing written.'); process.exit(1); }
fs.writeFileSync(file, s);
console.log('\nDONE: ' + ok + ' edit(s) written to ' + file);
