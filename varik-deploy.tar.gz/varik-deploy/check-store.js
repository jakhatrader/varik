// check-store.js — read-only sanity check of the Upstash index BEFORE going live.
// Prints how many tweets / accounts are stored and the newest + oldest dates,
// without writing anything and without touching twitterapi.io.
//
// Usage:
//   cd /root/varik && set -a && source .env && set +a && node check-store.js
'use strict';
const zlib = require('zlib');

const U = (process.env.UPSTASH_REDIS_REST_URL || '').replace(/\/+$/, '');
const T = process.env.UPSTASH_REDIS_REST_TOKEN || '';
const KEY = process.env.STORE_KEY || 'pv:index';

async function cmd(args) {
	const r = await fetch(U, {
		method: 'POST',
		headers: { Authorization: 'Bearer ' + T, 'Content-Type': 'application/json' },
		body: JSON.stringify(args),
	});
	if (!r.ok) throw new Error('redis HTTP ' + r.status + ': ' + (await r.text()).slice(0, 200));
	const j = await r.json();
	if (j && j.error) throw new Error('redis: ' + j.error);
	return j ? j.result : null;
}

(async () => {
	if (!U || !T) {
		console.error('ERROR: UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN not set.');
		console.error('Run:  cd /root/varik && set -a && source .env && set +a && node check-store.js');
		process.exit(1);
	}
	console.log('store key : ' + KEY);
	const meta = await cmd(['GET', KEY + ':meta']);
	const n = parseInt(meta, 10);
	if (!(n > 0)) {
		console.log('RESULT    : EMPTY — no index found under this key.');
		console.log('            Check STORE_KEY in .env and that this is the right Upstash database.');
		process.exit(2);
	}
	console.log('chunks    : ' + n);

	let gz = '';
	for (let i = 0; i < n; i++) {
		const part = await cmd(['GET', KEY + ':' + i]);
		if (part == null) throw new Error('missing chunk ' + i + '/' + n + ' — index is incomplete');
		gz += part;
		process.stdout.write('\rreading   : ' + (i + 1) + '/' + n);
	}
	process.stdout.write('\n');

	const store = JSON.parse(zlib.gunzipSync(Buffer.from(gz, 'base64')).toString('utf8'));
	const ids = Object.keys(store.tweets || {});
	const users = new Set();
	let views = 0, oldest = Infinity, newest = 0;
	for (const id of ids) {
		const r = store.tweets[id];
		users.add((r.h || '').toLowerCase());
		views += r.v || 0;
		if (r.t) { if (r.t < oldest) oldest = r.t; if (r.t > newest) newest = r.t; }
	}
	const d = (ms) => (ms && isFinite(ms) ? new Date(ms).toISOString().slice(0, 10) : 'n/a');

	console.log('');
	console.log('RESULT    : OK — index is readable and intact');
	console.log('tweets    : ' + ids.length.toLocaleString('en-US'));
	console.log('accounts  : ' + users.size.toLocaleString('en-US'));
	console.log('views     : ' + views.toLocaleString('en-US'));
	console.log('range     : ' + d(oldest) + '  ->  ' + d(newest));
	console.log('saved at  : ' + (store.updatedAt ? new Date(store.updatedAt).toISOString() : 'unknown'));
	console.log('backfill  : ' + (store.backfillDone ? 'complete' : 'was in progress'));
	console.log('');
	console.log('Safe to start the app: systemctl start varik');
})().catch((e) => {
	console.error('\nFAILED: ' + e.message);
	process.exit(1);
});
