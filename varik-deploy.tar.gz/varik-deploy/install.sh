#!/usr/bin/env bash
# install.sh — put ogvar.xyz back online on a fresh Ubuntu 22.04/24.04 VPS.
# Run as root from inside the unpacked folder:
#
#   bash install.sh
#
# Safe to re-run: it never overwrites an existing .env and never starts the app
# before the index has been verified.
set -euo pipefail

DOMAIN="${DOMAIN:-ogvar.xyz}"
APP_DIR="${APP_DIR:-/root/varik}"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

say()  { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m[!] %s\033[0m\n' "$*"; }

[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo bash install.sh"; exit 1; }

say "1/6  System packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq curl ca-certificates nginx >/dev/null

node_major() { command -v node >/dev/null && node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0; }

if [ "$(node_major)" -lt 18 ]; then
	# Ubuntu 24.04+ ships Node 18/20/22 in its own repos — prefer that, it always
	# matches the release. NodeSource is only a fallback for older distros.
	say "     Installing Node.js (need >=18 for built-in fetch)"
	apt-get install -y -qq nodejs >/dev/null 2>&1 || true
	if [ "$(node_major)" -lt 18 ]; then
		warn "distro Node is too old or missing — falling back to NodeSource"
		curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null
		apt-get install -y -qq nodejs >/dev/null
	fi
fi
[ "$(node_major)" -ge 18 ] || { echo "FATAL: could not install Node.js >=18"; exit 1; }
echo "     node $(node -v)  |  nginx $(nginx -v 2>&1 | cut -d/ -f2)"

say "2/6  App files -> $APP_DIR"
mkdir -p "$APP_DIR"
cp -r "$SRC_DIR/server.js" "$SRC_DIR/classify.js" "$SRC_DIR/package.json" "$SRC_DIR/public" "$APP_DIR/"
cp "$SRC_DIR"/check-store.js "$SRC_DIR"/restore-store.js "$SRC_DIR"/clean-index.js "$SRC_DIR"/backup-store.sh "$APP_DIR/"
chmod +x "$APP_DIR/backup-store.sh"

if [ -f "$APP_DIR/.env" ]; then
	echo "     .env already exists — left untouched"
else
	cp "$SRC_DIR/.env.example" "$APP_DIR/.env"
	chmod 600 "$APP_DIR/.env"
	warn ".env created from the template — you must fill in 3 values before the site can start:"
	warn "    TWITTERAPI_KEY, UPSTASH_REDIS_REST_URL, UPSTASH_REDIS_REST_TOKEN"
	warn "    nano $APP_DIR/.env"
fi

say "3/6  systemd service"
cp "$SRC_DIR/varik.service" /etc/systemd/system/varik.service
systemctl daemon-reload
systemctl enable varik >/dev/null 2>&1
echo "     varik.service installed (not started yet)"

say "4/6  nginx site for $DOMAIN"
sed "s/ogvar\.xyz/$DOMAIN/g" "$SRC_DIR/ogvar.nginx.conf" > /etc/nginx/sites-available/ogvar
ln -sf /etc/nginx/sites-available/ogvar /etc/nginx/sites-enabled/ogvar
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
echo "     nginx reloaded"

say "5/6  Nightly index backup (03:20 UTC)"
# `grep -v` exits 1 when the crontab is empty, which under `set -o pipefail`
# would abort the whole install — hence the `|| true`.
( { crontab -l 2>/dev/null || true; } | grep -v 'backup-store.sh' || true; \
  echo "20 3 * * * $APP_DIR/backup-store.sh >> /var/log/varik-backup.log 2>&1" ) | crontab -
echo "     cron installed -> /root/varik-backups"

say "6/6  Next steps"
cat <<EOF

  This machine's public IP:  $(curl -fsS --max-time 5 https://api.ipify.org || echo '<run: curl https://api.ipify.org>')

  1) Fill in the secrets:
       nano $APP_DIR/.env

  2) Verify the old index is readable (reads only, costs nothing):
       cd $APP_DIR && set -a && source .env && set +a && node check-store.js
     Expect "RESULT: OK" plus the tweet/account counts. If it says EMPTY, stop
     and check STORE_KEY / that it is the right Upstash database.

  3) Start it:
       systemctl start varik
       curl -s localhost:3000/api/health

  4) Point DNS at this server (Namecheap -> Domain List -> ogvar.xyz -> Advanced DNS):
       change the A record for @ from 81.19.137.250 to the IP above,
       and add A record for www to the same IP. TTL: Automatic.

  5) Once DNS resolves here, add HTTPS:
       certbot --nginx -d $DOMAIN -d www.$DOMAIN
     (install first if needed: apt-get install -y certbot python3-certbot-nginx)

EOF
