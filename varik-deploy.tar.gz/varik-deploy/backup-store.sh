#!/usr/bin/env bash
# backup-store.sh — nightly local snapshot of the Upstash index, so losing either
# the server or the Upstash account never wipes the history again.
# Keeps the last 14 snapshots in /root/varik-backups.
set -euo pipefail

APP_DIR="${APP_DIR:-/root/varik}"
OUT_DIR="${OUT_DIR:-/root/varik-backups}"
KEEP="${KEEP:-14}"

cd "$APP_DIR"
set -a; . ./.env; set +a
mkdir -p "$OUT_DIR"

STAMP="$(date -u +%Y%m%d-%H%M)"
OUT="$OUT_DIR/pv-index-$STAMP.json.gz"

node -e '
const zlib=require("zlib"),fs=require("fs");
const U=(process.env.UPSTASH_REDIS_REST_URL||"").replace(/\/+$/,"");
const T=process.env.UPSTASH_REDIS_REST_TOKEN||"";
const KEY=process.env.STORE_KEY||"pv:index";
const OUT=process.argv[1];
async function cmd(a){const r=await fetch(U,{method:"POST",headers:{Authorization:"Bearer "+T,"Content-Type":"application/json"},body:JSON.stringify(a)});if(!r.ok)throw new Error("redis "+r.status);const j=await r.json();if(j&&j.error)throw new Error(j.error);return j?j.result:null;}
(async()=>{
  const n=parseInt(await cmd(["GET",KEY+":meta"]),10);
  if(!(n>0))throw new Error("no index stored under "+KEY);
  let gz="";
  for(let i=0;i<n;i++){const p=await cmd(["GET",KEY+":"+i]);if(p==null)throw new Error("missing chunk "+i);gz+=p;}
  const buf=Buffer.from(gz,"base64");
  zlib.gunzipSync(buf); // verify it decompresses before we call this a backup
  fs.writeFileSync(OUT,buf);
  console.log("backup ok: "+OUT+" ("+(buf.length/1048576).toFixed(1)+" MB, "+n+" chunks)");
})().catch(e=>{console.error("backup FAILED: "+e.message);process.exit(1);});
' "$OUT"

ls -1t "$OUT_DIR"/pv-index-*.json.gz | tail -n +$((KEEP + 1)) | xargs -r rm -f
