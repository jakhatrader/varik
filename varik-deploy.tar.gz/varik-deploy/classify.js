/* classify.js — decides whether a tweet is about Variational the perp DEX.
 *
 * The problem this solves: "variational" is a machine-learning term (variational
 * autoencoder, variational inference, variational Bayes). Counting the bare word
 * put AI researchers and academic publishers on the leaderboard — @ylecun writes
 * about variational inference, not about perps.
 *
 * So the word alone is no longer a signal. What counts:
 *   1. a mention of @variational_io                    — nobody in ML @-mentions it
 *   2. a link to variational.io / omni.variational.io  — unambiguous
 *   3. the word "variational" PLUS a crypto-context word AND no science vocabulary
 *
 * $VAR on its own still does not count: too many unrelated tokens share the ticker.
 *
 * Both word lists can be overridden from .env (PROJECT_WORDS, SCIENCE_WORDS) as
 * comma-separated lists, so tuning does not need a code change.
 *
 * Shared by server.js (at index time, with the full tweet) and clean-index.js
 * (retroactively, over the 240 characters kept per record).
 */
'use strict';

function envList(name, def) {
	return String(process.env[name] || def)
		.toLowerCase()
		.split(',')
		.map((s) => s.trim())
		.filter(Boolean);
}

// Crypto / product context. One of these has to appear next to the keyword for a
// tweet to count. Deliberately broad: it only ever ADMITS a tweet that already
// contains "variational" and carries no science vocabulary.
const PROJECT_WORDS = envList('PROJECT_WORDS', [
	'variational_io', 'variational.io', 'perp', 'perps', 'perpetual', 'dex', 'cex',
	'trading', 'trade', 'trader', 'trades', 'leverage', 'liquidity', 'rfq', 'arbitrum',
	'onchain', 'on-chain', 'defi', 'airdrop', 'points', 'testnet', 'mainnet', 'tvl',
	'funding', 'margin', 'position', 'wallet', 'token', '$var', 'vault', 'orderbook',
	'order book', 'yield', 'farming', 'settle', 'settlement', 'escrow', 'otc', 'pnl',
	'degen', 'mint', 'whitelist', 'quest', 'referral', 'fee', 'fees', 'zero-fee',
	'50x', 'long', 'short', 'volume', 'crypto', 'exchange', 'protocol', 'liquidation',
	'spot', 'futures', 'staking', 'bullish', 'ape', 'alpha', 'season', 'listing'
].join(','));

// Academic / ML vocabulary. Any of these vetoes the keyword path outright — these
// are terms that effectively never show up in crypto promotion.
const SCIENCE_WORDS = envList('SCIENCE_WORDS', [
	'autoencoder', 'autoencoders', 'vae', 'variational inference', 'variational bayes',
	'bayes', 'bayesian', 'posterior', 'prior distribution', 'elbo', 'evidence lower bound',
	'kl divergence', 'kullback', 'latent space', 'latent variable', 'monte carlo', 'mcmc',
	'free energy', 'mean field', 'arxiv', 'neurips', 'nips', 'icml', 'iclr', 'acl',
	'preprint', 'peer review', 'professor', 'phd', 'postdoc', 'lecture', 'textbook',
	'journal', 'citation', 'quantum', 'hamiltonian', 'lagrangian', 'eigen', 'manifold',
	'theorem', 'lemma', 'calculus', 'pde', 'partial differential', 'gaussian',
	'marginal likelihood', 'gradient descent', 'backprop', 'neural network',
	'deep learning', 'machine learning', 'dataset', 'transformer', 'diffusion model',
	'autoregressive', 'inference network', 'em algorithm', 'renormalization',
	'functional analysis', 'approximation theory', 'regularization', 'embedding space'
].join(','));

function hasAny(low, words) {
	for (let i = 0; i < words.length; i++) if (low.indexOf(words[i]) !== -1) return true;
	return false;
}

/* opts: { atV, kw, varTag, text, urls } — urls are expanded URLs when available.
 * Returns { relevant, why } so the cleanup script can explain its decisions. */
function relevance(opts) {
	const low = String(opts.text || '').toLowerCase();
	const urls = (opts.urls || []).join(' ').toLowerCase();

	if (opts.atV) return { relevant: true, why: 'mentions @variational_io' };
	if (urls.indexOf('variational.io') !== -1 || low.indexOf('variational.io') !== -1) {
		return { relevant: true, why: 'links variational.io' };
	}
	if (opts.kw) {
		if (hasAny(low, SCIENCE_WORDS)) return { relevant: false, why: 'science/ML context' };
		if (hasAny(low, PROJECT_WORDS)) return { relevant: true, why: 'keyword + crypto context' };
		return { relevant: false, why: 'keyword with no context' };
	}
	return { relevant: false, why: 'no signal' }; // $VAR alone never qualifies
}

module.exports = { relevance, PROJECT_WORDS, SCIENCE_WORDS };
