// restore-store.js — push a local backup (made by backup-store.sh) back into Upstash.
// Use only if the Upstash index is lost or corrupted.
//
//   systemctl stop varik            # stop the app first, or it may overwrite you
//   cd /root/varik && set -a && source .env && set +a
//   node restore-store.js /root/varik-backups/pv-index-YYYYMMDD-HHMM.json.gz
//   systemctl start varik
'use strict';
const fs = require('fs');
const zlib = require('zlib');

const U = (process.env.UPSTASH_REDIS_REST_URL || '').replace(/\/+$/, '');
const T = process.env.UPSTASH_REDIS_REST_TOKEN || '';
const KEY = process.env.STORE_KEY || 'pv:index';
const CHUNK = 200 * 1024; // must match REDIS_CHUNK in server.js
const FILE = process.argv[2];

async function cmd(args) {
	const r = await fetch(U, {
		method: 'POST',
		headers: { Authorization: 'Bearer ' + T, 'Content-Type': 'application/json' },
		body: JSON.stringify(args),
	});
	if (!r.ok) throw new Error('redis HTTP ' + r.status + ': ' + (await r.text()).slice(0, 200));
	const j = await r.json();
	if (j && j.error) throw new Error('redis: ' + j.error);
	return j ? j.result : null;
}

(async () => {
	if (!U || !T) throw new Error('UPSTASH env missing — did you "set -a && source .env"?');
	if (!FILE) throw new Error('usage: node restore-store.js <backup.json.gz>');

	const buf = fs.readFileSync(FILE);
	const store = JSON.parse(zlib.gunzipSync(buf).toString('utf8')); // verify before writing
	const count = Object.keys(store.tweets || {}).length;
	if (!count) throw new Error('backup contains no tweets — refusing to restore it');
	console.log('backup holds ' + count.toLocaleString('en-US') + ' tweets, saved ' +
		(store.updatedAt ? new Date(store.updatedAt).toISOString() : 'unknown'));

	const gz = buf.toString('base64');
	const n = Math.ceil(gz.length / CHUNK) || 1;
	for (let i = 0; i < n; i++) {
		await cmd(['SET', KEY + ':' + i, gz.slice(i * CHUNK, (i + 1) * CHUNK)]);
		process.stdout.write('\rwriting   : ' + (i + 1) + '/' + n);
	}
	await cmd(['SET', KEY + ':meta', String(n)]);
	process.stdout.write('\n');
	console.log('restored to ' + KEY + ' (' + n + ' chunks). Now: systemctl start varik');
})().catch((e) => { console.error('FAILED: ' + e.message); process.exit(1); });
