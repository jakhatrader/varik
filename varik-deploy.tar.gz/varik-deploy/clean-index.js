/* clean-index.js — re-checks the already collected index against the current rules
 * in classify.js and removes records that no longer qualify.
 *
 * Why it exists: relevance is decided once, at index time. When the rules change,
 * everything already stored keeps its old verdict — which is how ML researchers
 * writing about variational inference stayed on the leaderboard.
 *
 * Costs nothing: reads and writes Upstash only, never touches twitterapi.io.
 * Each record keeps the first 240 characters of its tweet, and that text is what
 * gets re-checked — context past that point is not available, so a handful of
 * genuine posts may fall out with the junk.
 *
 *   systemctl stop varik                       # or it will overwrite the result
 *   cd /root/varik && set -a && source .env && set +a
 *   node clean-index.js                        # dry run: reports, writes nothing
 *   CONFIRM=1 node clean-index.js              # actually remove
 *   systemctl start varik
 */
'use strict';
const zlib = require('zlib');
const { relevance } = require('./classify');

const path = require('path');
const fs = require('fs');

const U = (process.env.UPSTASH_REDIS_REST_URL || '').replace(/\/+$/, '');
const T = process.env.UPSTASH_REDIS_REST_TOKEN || '';
const KEY = process.env.STORE_KEY || 'pv:index';
const CHUNK = 200 * 1024; // must match REDIS_CHUNK in server.js
const WRITE = process.env.CONFIRM === '1';
const SHOW = parseInt(process.env.SHOW || '25', 10);
// Same fallback as the server: no Upstash credentials means the index is a local file.
const STORE_FILE = process.env.STORE_FILE || path.join(__dirname, 'store.json');
const USE_REDIS = !!(U && T);

async function cmd(args) {
	const r = await fetch(U, {
		method: 'POST',
		headers: { Authorization: 'Bearer ' + T, 'Content-Type': 'application/json' },
		body: JSON.stringify(args),
	});
	if (!r.ok) throw new Error('redis HTTP ' + r.status + ': ' + (await r.text()).slice(0, 200));
	const j = await r.json();
	if (j && j.error) throw new Error('redis: ' + j.error);
	return j ? j.result : null;
}

const n = (x) => x.toLocaleString('en-US');

(async () => {
	let store, parts = 0;
	if (USE_REDIS) {
		const meta = await cmd(['GET', KEY + ':meta']);
		parts = parseInt(meta, 10);
		if (!(parts > 0)) throw new Error('no index stored under ' + KEY);
		let gz = '';
		for (let i = 0; i < parts; i++) {
			const p = await cmd(['GET', KEY + ':' + i]);
			if (p == null) throw new Error('missing chunk ' + i + '/' + parts);
			gz += p;
			process.stdout.write('\rreading   : ' + (i + 1) + '/' + parts);
		}
		process.stdout.write('\n');
		store = JSON.parse(zlib.gunzipSync(Buffer.from(gz, 'base64')).toString('utf8'));
		console.log('store     : Upstash, key ' + KEY);
	} else {
		if (!fs.existsSync(STORE_FILE)) throw new Error('no Upstash credentials and no ' + STORE_FILE);
		store = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8'));
		console.log('store     : local file ' + STORE_FILE);
	}
	const ids = Object.keys(store.tweets || {});
	if (!ids.length) throw new Error('index holds no tweets');

	const keep = {};
	const reasons = {};
	// Per account: what stays and what goes, so the report shows who disappears.
	const acct = {};
	let dropped = 0, droppedViews = 0, keptViews = 0;

	for (const id of ids) {
		const r = store.tweets[id];
		const key = (r.h || '').toLowerCase();
		if (!acct[key]) acct[key] = { h: r.h, keep: 0, drop: 0, keepV: 0, dropV: 0, sample: '' };
		const res = relevance({ atV: !!r.atV, kw: !!r.kw, varTag: !!r.vt, text: r.text || '' });
		if (res.relevant) {
			keep[id] = r;
			keptViews += r.v || 0;
			acct[key].keep++; acct[key].keepV += r.v || 0;
		} else {
			dropped++;
			droppedViews += r.v || 0;
			reasons[res.why] = (reasons[res.why] || 0) + 1;
			acct[key].drop++; acct[key].dropV += r.v || 0;
			if (!acct[key].sample) acct[key].sample = String(r.text || '').replace(/\s+/g, ' ').slice(0, 90);
		}
	}

	const accounts = Object.keys(acct);
	const gone = accounts.filter((k) => acct[k].keep === 0 && acct[k].drop > 0);
	const kept = ids.length - dropped;

	console.log('');
	console.log('index     : ' + n(ids.length) + ' tweets · ' + n(accounts.length) + ' accounts');
	console.log('keep      : ' + n(kept) + ' tweets · ' + n(keptViews) + ' views');
	console.log('drop      : ' + n(dropped) + ' tweets · ' + n(droppedViews) + ' views');
	console.log('accounts  : ' + n(gone.length) + ' disappear entirely, ' + n(accounts.length - gone.length) + ' remain');
	console.log('');
	console.log('why dropped:');
	Object.keys(reasons).sort((a, b) => reasons[b] - reasons[a])
		.forEach((w) => console.log('  ' + String(reasons[w]).padStart(7) + '  ' + w));

	console.log('');
	console.log('biggest accounts that disappear (by dropped views):');
	gone.sort((a, b) => acct[b].dropV - acct[a].dropV).slice(0, SHOW).forEach((k, i) => {
		const a = acct[k];
		console.log('  ' + String(i + 1).padStart(3) + '. @' + a.h + '  ' + n(a.dropV) + ' views, ' + a.drop + ' posts');
		if (a.sample) console.log('        "' + a.sample + '"');
	});

	// Accounts that only partly shrink are worth a look too: a real supporter should
	// not lose most of their posts.
	const trimmed = accounts.filter((k) => acct[k].keep > 0 && acct[k].drop > 0);
	console.log('');
	console.log('accounts that only shrink: ' + n(trimmed.length));
	trimmed.sort((a, b) => acct[b].dropV - acct[a].dropV).slice(0, 10).forEach((k) => {
		const a = acct[k];
		console.log('   @' + a.h + '  keeps ' + a.keep + ', loses ' + a.drop + ' (' + n(a.dropV) + ' views)');
	});

	if (!WRITE) {
		console.log('');
		console.log('DRY RUN — nothing was written.');
		console.log('If the list above looks right:  CONFIRM=1 node clean-index.js');
		return;
	}

	store.tweets = keep;
	store.count = kept;
	// Recompute the window bounds; the oldest/newest tweet may well have been junk.
	let oldest = 0, newest = 0;
	for (const id in keep) {
		const t = keep[id].t;
		if (!t) continue;
		if (!oldest || t < oldest) oldest = t;
		if (t > newest) newest = t;
	}
	store.oldestTime = oldest;
	store.newestTime = newest;
	store.updatedAt = Date.now();

	const str = JSON.stringify(store);
	if (USE_REDIS) {
		const gzOut = zlib.gzipSync(Buffer.from(str, 'utf8')).toString('base64');
		const outParts = Math.ceil(gzOut.length / CHUNK) || 1;
		for (let i = 0; i < outParts; i++) {
			await cmd(['SET', KEY + ':' + i, gzOut.slice(i * CHUNK, (i + 1) * CHUNK)]);
			process.stdout.write('\rwriting   : ' + (i + 1) + '/' + outParts);
		}
		await cmd(['SET', KEY + ':meta', String(outParts)]);
		// Leftover chunks from the previous, larger blob would confuse a later read.
		for (let i = outParts; i < parts; i++) await cmd(['DEL', KEY + ':' + i]);
		process.stdout.write('\n');
	} else {
		fs.writeFileSync(STORE_FILE, str);
	}

	console.log('');
	console.log('WRITTEN: index is now ' + n(kept) + ' tweets.');
	console.log('Start the app: systemctl start varik');
})().catch((e) => { console.error('\nFAILED: ' + e.message); process.exit(1); });
