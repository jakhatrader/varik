# ogvar.xyz — восстановление после потери сервера

Код собран и проверен: сервер запускается, лидерборд, профили (`/u/handle`) и API
отвечают. Осталось поднять его на новом VPS и перевести домен.

**Главное:** индекс твитов лежит в Upstash Redis под ключом `pv:index` и он цел.
Бэкфилл (перезалив истории) **не нужен** — в `.env` оставь `BACKFILL=0`.
Ключ twitterapi.io нужен только для ежедневного лёгкого апдейта (только новые твиты).

---

## Что где

| Файл | Зачем |
|---|---|
| `server.js` | бэкенд, все патчи уже применены (windowed backfill, winfix, img-прокси) |
| `public/index.html` | сайт целиком, патчи trust + UI применены, домен зашит `ogvar.xyz` |
| `install.sh` | одна команда: ставит Node/nginx, кладёт приложение, systemd, cron-бэкап |
| `.env.example` | шаблон конфига → станет `.env` на сервере |
| `varik.service` | systemd-юнит (вместо pm2: автозапуск, рестарт при падении) |
| `ogvar.nginx.conf` | nginx на `ogvar.xyz` + `www` → localhost:3000 |
| `check-store.js` | проверка, что индекс в Upstash читается (только чтение, бесплатно) |
| `backup-store.sh` | ночной бэкап индекса на диск, ставится в cron автоматически |
| `restore-store.js` | залить бэкап обратно в Upstash, если он когда-нибудь потеряется |
| `patches/` | исходные патч-скрипты, уже применённые — на память |

---

## Шаг 1. Сервер

Любой VPS с Ubuntu 22.04 или 24.04, хватит самого дешёвого (1 vCPU / 1 GB).
Залей папку и запусти установку:

```bash
scp -r varik-deploy root@НОВЫЙ_IP:/root/
ssh root@НОВЫЙ_IP
cd /root/varik-deploy && bash install.sh
```

Скрипт поставит Node 20, nginx, приложение в `/root/varik`, systemd-сервис `varik`,
nginx-сайт и ночной бэкап. Приложение пока не стартует — нужны секреты.

## Шаг 2. Секреты

```bash
nano /root/varik/.env
```

Заполнить три строки:

- `TWITTERAPI_KEY` — из дашборда twitterapi.io
- `UPSTASH_REDIS_REST_URL` и `UPSTASH_REDIS_REST_TOKEN` — Upstash → твоя база → вкладка
  **REST API** → скопировать как есть

`STORE_KEY=pv:index` **не менять** — старые данные лежат именно под этим именем.

## Шаг 3. Проверить, что история на месте (до запуска)

```bash
cd /root/varik && set -a && source .env && set +a && node check-store.js
```

Должно вывести `RESULT: OK` и количество твитов/аккаунтов/просмотров.
Если `EMPTY` — не та база Upstash или не тот `STORE_KEY`; **не запускай сервер**,
пока не разберёшься (в коде есть защита от перезаписи, но лучше не проверять её).

## Шаг 4. Запуск

```bash
systemctl start varik
curl -s localhost:3000/api/health
```

В ответе смотри `"indexed"` — это число твитов из Upstash. Если оно совпало с
`check-store.js`, сайт уже живой на `http://НОВЫЙ_IP/`.

Логи: `tail -f /var/log/varik.log`

## Шаг 5. Домен

Домен на **Namecheap**, NS штатные (`dns1/dns2.registrar-servers.com`), менять их не надо.
Сейчас A-запись указывает на мёртвый Aeza-IP **81.19.137.250**.

Namecheap → Domain List → `ogvar.xyz` → **Advanced DNS**:

| Type | Host | Value | TTL |
|---|---|---|---|
| A Record | `@` | НОВЫЙ_IP | Automatic |
| A Record | `www` | НОВЫЙ_IP | Automatic |

Старую A-запись на 81.19.137.250 удалить. Обновление занимает ~10–30 минут
(текущий TTL 1800 с). Проверка: `dig +short ogvar.xyz` или
`https://dns.google/resolve?name=ogvar.xyz&type=A`.

## Шаг 6. HTTPS

Когда домен резолвится на новый IP:

```bash
apt-get install -y certbot python3-certbot-nginx
certbot --nginx -d ogvar.xyz -d www.ogvar.xyz
```

Certbot сам допишет 443-блок в nginx и настроит автопродление.

---

## Чтобы это не повторилось

- **Автопродление VPS.** Главная причина падения — не продлил Aeza. Включи автоплатёж
  и поставь напоминание за неделю.
- **Бэкап уже настроен.** `install.sh` добавил в cron ночной дамп индекса в
  `/root/varik-backups` (хранятся последние 14). Проверить: `crontab -l`,
  лог — `/var/log/varik-backup.log`.
- **Данные переживают сервер.** Индекс в Upstash, а не на диске — поэтому история и
  уцелела сейчас. Не переводи хранилище на локальный файл.
- Если Upstash когда-нибудь потеряется: `systemctl stop varik`, затем
  `node restore-store.js /root/varik-backups/pv-index-*.json.gz`, затем `systemctl start varik`.

---

## Расход twitterapi.io

При `BACKFILL=0` сервер раз в сутки тянет только новые твиты: несколько запросов,
копейки. Жёсткий потолок `MAX_REQUESTS_PER_DAY=500` в `.env` не даст кредитам утечь.

`BACKFILL=1` включай только если реально надо перестроить историю с нуля — вот это
дорого: сервер пойдёт листать всю выдачу X с 2024-02-01 постранично.

---

## Полезные команды

```bash
systemctl status varik          # состояние
systemctl restart varik         # перезапуск после правок .env
journalctl -u varik -n 50       # системные логи юнита
tail -f /var/log/varik.log      # логи приложения
curl -s localhost:3000/api/health | python3 -m json.tool
/root/varik/backup-store.sh     # бэкап вручную
```
